=== Wp anything slider ===
Contributors: www.gopiplus.com, gopiplus
Donate link: http://www.gopiplus.com/work/2012/04/20/wordpress-plugin-wp-anything-slider/
Author URI: http://www.gopiplus.com/work/2012/04/20/wordpress-plugin-wp-anything-slider/
Plugin URI: http://www.gopiplus.com/work/2012/04/20/wordpress-plugin-wp-anything-slider/
Tags:  wordpress, plugin, anything, slider
Requires at least: 3.4
Tested up to: 4.5
Stable tag: 7.8
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
	
Wp anything slider plugin let you to create the sliding slideshow into your posts & pages. In admin we have Tiny MCE editor to add the content.

== Description ==

Check official website for live demo [http://www.gopiplus.com/work/2012/04/20/wordpress-plugin-wp-anything-slider/](http://www.gopiplus.com/work/2012/04/20/wordpress-plugin-wp-anything-slider/)

*   [Live Demo](http://www.gopiplus.com/work/2012/04/20/wordpress-plugin-wp-anything-slider/)		
*   [More info](http://www.gopiplus.com/work/2012/04/20/wordpress-plugin-wp-anything-slider/)					
*   [Comments/Suggestion](http://www.gopiplus.com/work/2012/04/20/wordpress-plugin-wp-anything-slider/)			
*   [About author](http://www.gopiplus.com/work/2012/04/20/wordpress-plugin-wp-anything-slider/)				

Wp anything slider plugin let you to create the sliding slideshow gallery into your posts and pages. In the admin we have Tiny MCE HTML editor to add, update the content. using this HTML editor we can add HTML text and can upload the images and video files. whatever the content you added in the admin, the plug-in will slide it in the front end, so it is named anything slider. also we have four types of sliding direction, you can choose the one you like for the gallery.

**Features of this plugin**

* Simple installation and customization.
* Four different sliding option.
* Tiny MCE HTML editor to add the content and images.
* Option to upload video files.

**Plugin configuration**

Plugin configuration

Add directly in the theme:

Paste this PHP code `<?php wpanything('etting1'); ?>` in your theme where you want the announcement to appear.

Short code for posts and pages:

Copy and paste the below given short code into pages or posts to display the news
Short code : `[wp-anything-slider setting="SETTING1"]`

Plugin configuration

After activated the plugin, go to plugin menu on your WordPress dashboard to manage the news content and to configure the setting,

Dashboard --> Settings --> Wp Anything Slider

== Installation ==	

[Installation instruction and configuration](http://www.gopiplus.com/work/2012/04/20/wordpress-plugin-wp-anything-slider/)

== Frequently asked questions ==

[Frequently asked questions](http://www.gopiplus.com/work/2012/04/20/wordpress-plugin-wp-anything-slider/)

Q) How can I change the display style?

== Screenshots ==

1. Front Screen. http://www.gopiplus.com/work/2012/04/20/wordpress-plugin-wp-anything-slider/

2. Admin Screen. http://www.gopiplus.com/work/2012/04/20/wordpress-plugin-wp-anything-slider/

== Upgrade Notice ==

= 7.8 =

1. Tested up to 4.5
2. Sanitization added for all input value.

= 7.7 =

1. Tested up to 4.4
2. Text Domain slug has been added for Language Packs.

= 7.6 =

1. Tested up to 4.3

= 7.5 =

1. Tested up to 4.2.2

= 7.4 =

1. Tested up to 4.1

= 7.3 =

1. Tested up to 4.0

= 7.2 =

1. Tested up to 3.9
2. Restricted direct page access.

= 7.1 =

1. Tested up to 3.8
2. Now this plugin supports localization (or internationalization). i.e. option to translate into other languages. 
Plugin *.po file (wp-anything-slider.po) available in the languages folder.

= 7.0 =

Tested up to 3.6
Added few security features.
New admin layout.

= 6.0 =

Tested up to 3.5
Avoid registering the alternate jQuery.
From this version we are using existing wordpress jQuery.

= 5.0 =

Tested up to: 3.4.2

= 4.0 =

New demo link, www.gopiplus.com

= 3.0 =

JavaScript loaded by using the wp_enqueue_scripts hook (instead of the init hook), This will avoid the JavaScript, Jquery conflict.
Slight change in the short code, Please find the new short code for your slider.

= 2.0 =

Option to update the widget title

= 1.0 =  

First version.	

== Changelog ==

= 7.8 =

1. Tested up to 4.5
2. Sanitization added for all input value.

= 7.7 =

1. Tested up to 4.4
2. Text Domain slug has been added for Language Packs.

= 7.6 =

1. Tested up to 4.3

= 7.5 =

1. Tested up to 4.2.2

= 7.4 =

1. Tested up to 4.1

= 7.3 =

1. Tested up to 4.0

= 7.2 =

1. Tested up to 3.9
2. Restricted direct page access.

= 7.1 =

1. Tested up to 3.8
2. Now this plugin supports localization (or internationalization). i.e. option to translate into other languages. 
Plugin *.po file (wp-anything-slider.po) available in the languages folder.

= 7.0 =

Tested up to 3.6
Added few security features.
New admin layout.

= 6.0 =

Tested up to 3.5
Avoid registering the alternate jQuery.
From this version we are using existing wordpress jQuery.

= 5.0 =

Tested up to: 3.4.2

= 4.0 =

New demo link, www.gopiplus.com

= 3.0 =

JavaScript loaded by using the wp_enqueue_scripts hook (instead of the init hook), This will avoid the JavaScript, Jquery conflict.
Slight change in the short code, Please find the new short code for your slider.

= 2.0 =

Option to update the widget title

= 1.0 =  

First version.